package com.example.dontwastefood.Models;

import java.util.ArrayList;

public class RandomRecipeApiResponse {

    public ArrayList<Recipe> recipes;
}
