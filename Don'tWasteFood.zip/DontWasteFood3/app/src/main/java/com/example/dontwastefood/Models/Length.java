package com.example.dontwastefood.Models;

public class Length {
    public int number;
    public String unit;
}
